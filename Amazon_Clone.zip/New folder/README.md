# Amazon Clone Application using React JS



-  FULL Ecommerce functionality which includes both back-end and front-end
-  Login Page
-  Products Page
-  Cart and Checkout Page
- REAL Payments (Stripe Credit Card Payments)
-  Order History Page (Real time database)
-  Awesome animations like React Hover effects 



